
Ques2.-Use BLAST (Basic Local Alignment Search Tool) to compare the PDC gene sequence across different Saccharomyces cerevisiae strains and identify SNPs. (5 marks)

    Single-nucleotide polymorphisms (SNPs) are single base-pair substitutions that occur within and outside genes
# Source -https://www.ncbi.nlm.nih.gov/pmc/articles/PMC22154/#:~:text=Single%2Dnucleotide%20polymorphisms%20(SNPs)%20are%20single%20base%2Dpair,response%20(6%2C%207).

    Single nucleotide polymorphisms, frequently called SNPs (pronounced “snips”), are the most common type of genetic variation among people. Each SNP represents a difference in a single DNA building block, called a nucleotide. For example, a SNP may replace the nucleotide cytosine (C) with the nucleotide thymine (T) in a certain stretch of DNA.
    SNPs occur normally throughout a person’s DNA. They occur almost once in every 1,000 nucleotides on average, which means there are roughly 4 to 5 million SNPs in a person's genome
    Most SNPs have no effect on health or development.
    SNPs help predict an individual’s response to certain drugs, susceptibility to environmental factors such as toxins, and risk of developing diseases. SNPs can also be used to track the inheritance of disease-associated genetic variants within families.
# Source -https://medlineplus.gov/genetics/understanding/genomicresearch/snp/

There are multiple strains of Saccharomyces cerevisiae,we selected the Saccharomyces cerevisiae strain(S288C) as refrence genome as used in NCBI.
So Now using the NCBI BLAST tool  we can compare the PDC gene sequence across different Saccharomyces cerevisiae strains and identify SNPs.

As here we are comparing the nucleotide sequence against nucleotide seq wo we will be using BLASTn


I did this ques by two methods, first by manuaaly acceesing NCBI and using the simple approach

Basic Approach @ Web Method

    First search the Saccharomyces cerevisiae strain(S288C) as refrence genome as used in NCBI.
    Now, as we already found the PDC location in question 1,refer to that region(i,e,) chromosme and end and start seq index of PDC genes.
    Now specify the parametres for blast.
    Run the Blast,and wait for the result.
    Now go to Alignments sections,then Pairwise with dots for identities, Now we can see the SNP's.

Parametres of BLAST used: 

    ♦Set the organism name Saccharomyces cerevisiae
    ♦Optimise for  Optimize forHighly similar sequences (megablast)
    ♦Max target sequence=5000
    ♦Set the Expected value ,e=0.000000001(To have better confidence in the alignmnet)
    ♦Word size=16(default)
    ♦Scoring Parameters
        Match,Mismatch Scores= 1,-2
        Gap Costs=Existence:5,Extension:2(default)
    ♦Species-specific repeats for:Saccharomyces cerevisiae(Brewer's Yeast) 



PDC1  
    Go to Chromosome 12 of  Saccharomyces cerevisiae Reference genome sequence(Strain S288C) and  "start": 232390, "end": 234081, query lenth =1692

    For PDC1 I found 458 matches,Have attached the text file for that 

PDC5   
    Go to Chromosome 12 of  Saccharomyces cerevisiae Reference genome sequence(Strain S288C) and "start": 410723, "end": 412414,  query lenth =1691

    For PDC5 I found 458 matches,Have attached the text file for that 

PDC6   
    Go to Chromosome 7 of   Saccharomyces cerevisiae Reference genome sequence(Strain S288C)and  "start": 651290, "end": 652981,   query lenth =1692

    For PDC6 I found 456 matches,Have attached the text file for that 

PDC2   
    Go to Chromosome 4 of  Saccharomyces cerevisiae Reference genome sequence(Strain S288C) and "start": 607304, "end": 610081,  query lenth =2778

    For PDC2 I found 226 matches,Have attached the text file for that 


IN IMAGE RED COLOUR SHOWS SNP'S

By observing the sequences we can easily find the SNPS.  
SNPs (Single Nucleotide Polymorphisms) are not regions themselves but rather specific points within the genome where there is variation among individuals in terms of a single nucleotide base (adenine, cytosine, guanine, or thymine). These variations can occur within coding regions of genes, non-coding regions, or intergenic regions.


Second method is by writing a code,as given in BY_CODE folder,and XML files are generated for that

I have attached the screenshots  of BLAST search and SNP's for PDC1 AND PDC5 gene.

Some of the different strains of Saccharomyces cerevisiae PDC gens,I used
    

There are so many strains
SOME IDENTIFIED strains with SNP's in PDC genes;

PDC1

    #S.cerevisiae PDC1 gene, mutant pdc1-8
    #S.cerevisiae PDC1 gene, mutant pdc1-14
    #PDC1_strain EM14S01-3B
    #PDC1_strain BY4742
    #PDC1_strain DBVPG6765
    #PDC1_strain HB_C_TUKITUKI2_10

PDC5 

    #Saccharomyces cerevisiae strain HB_S_BILANCHER_12
    #Saccharomyces cerevisiae strain XXYS1.4 
    #Saccharomyces cerevisiae strain JXXY16.1

PDC6

    #Saccharomyces cerevisiae strain CDRDR_sf_H
    PDC6_strain SY14 

PDC2

    #PDC2_strain NCIM3186
    #PDC2_strain SK1

More are present in question 3





    
# Some SNPS   

    # Chromosome:position Reference/Variant nucleotides

    # PDC1 gene, mutant pdc1-8
    #Chr12:232468         G/A
    #Chr12:232470         T/C
    #Chr12:232471         T/C
    #Chr12:232561         A/G
    #Chr12:233075         G/T
    #Chr12:233211         C/T
    #Chr12:233324         T/C
    #Chr12:233325         C/T
    #Chr12:233459         G/A
    #Chr12:233460         A/G
    #Chr12:233464         A/G
    #Chr12:233465         G/A
    #Chr12:233766         C/A
    #Chr12:233917         G/C
    #Chr12:233918         C/G


    # PDC1_strain EM14S01-3B
    #Chr12:232561        A/G
    #Chr12:232714        G/A
    #Chr12:233011        A/G
    #Chr12:233028        T/C
    #Chr12:233158        G/A
    #Chr12:233200        A/G
    #Chr12:233566        G/A
    #Chr12:233797        A/T

    #PDC5 Saccharomyces cerevisiae strain HB_S_BILANCHER_12
    #Chr12:411601       T/C 

    #PDC5 Saccharomyces cerevisiae strain T52
    #chr12:411601       T/C




By code

code1.py, 

    this code retreives all the BLAST result and store them in the xml file,with certain parametres
    
    ♦Set the organism name Saccharomyces cerevisiae
    ♦Optimise for  Optimize forHighly similar sequences (megablast)
    ♦Max target sequence=5000
    ♦Set the Expected value ,e=0.000000001(To have better confidence in the alignmnet)
    ♦Word size=16(default)
    ♦Scoring Parameters
        Match,Mismatch Scores= 1,-2
        Gap Costs=Existence:5,Extension:2(default)
    ♦Species-specific repeats for:Saccharomyces cerevisiae(Brewer's Yeast) 

code2.py, 

        this code retrives all the seqeunce with more than 99.8% identity and less than 99% identity,we can change that. I sat that to get the sequences of most similarities.

        Parsing BLAST Results: The code takes input files containing BLAST results in XML format (PDC1_sequence.xml, x_PDC2_expression_gene.xml, PDC5_sequence.xml, PDC6_sequence.xml). These files contain alignment information between query sequences and subject sequences.

        Identifying SNPs: For each alignment in the BLAST results, the code calculates the percentage identity between the query sequence and the subject sequence. If the percentage identity falls within a specific range (98.9% to 99%), it suggests a potential SNP (Single Nucleotide Polymorphism).

        Storing Mutation Information: The code identifies SNPs by comparing each position in the query sequence with the corresponding position in the subject sequence. It then stores SNP information, including the position of the mutation and the mutation itself, in dictionaries (snp_dict and strain_mutations).

        Writing SNP Information to Files: The identified SNPs are written to output files ({output_filename}_SNPS.txt). Each SNP is associated with its position and the subject sequence it was found in.

        Identifying Strains with Mutations: Additionally, the code identifies strains (subject sequences) that contain mutations. It stores this information in the strain_mutations dictionary.

        Writing Strain Information to Files: The strains with mutations and their corresponding mutations are written to output files ({output_filename}_strains.txt). Each strain is associated with its mutations and their positions.

        Extracting Nucleotide Sequences for Mutant Strains: In main1, the code extracts nucleotide sequences for the strains that were identified to have mutations in the previous step. It creates FASTA files containing the nucleotide sequences of the strains with mutations, which are stored in separate files ({output_filename}_{i}.fasta).














        


