from Bio import SeqIO
from Bio.Blast import NCBIWWW
from Bio import Entrez

def fetch_sequence(accession_number):
    Entrez.email = "syed22530@iiitd.ac.in"  # Provide your email
    handle = Entrez.efetch(db="nucleotide", id=accession_number, rettype="fasta", retmode="text")
    seq_record = SeqIO.read(handle, "fasta")
    handle.close()
    return seq_record

def blast_search(sequence, start, end, output_filename):
    organism = "Saccharomyces cerevisiae"
    e_value = 0.000000001
    max_target_seqs = 5000
    word_size = 16
    gap_existence = 5
    gap_extension = 2

    # Extract the specified region
    subsequence = sequence.seq[start - 1:end]

    # Perform BLAST search
    handle = NCBIWWW.qblast(
        "blastn",
        "nt",
        subsequence,
        entrez_query=f'{organism}[Organism]',
        expect=e_value,
        word_size=word_size,
        gapcosts=f"{gap_existence} {gap_extension}",
        hitlist_size=max_target_seqs
    )

    # Write BLAST results to a file
    with open(output_filename, "w") as out_file:
        out_file.write(handle.read())

# List of sequences to search
sequences_to_search = [
    {"accession_number": "BK006945.2", "start": 232390, "end": 234081, "output_filename": "PDC1_sequence.xml"},
    {"accession_number": "BK006945.2", "start": 410723, "end": 412414, "output_filename": "PDC5_sequence.xml"},
    {"accession_number": "BK006941.2", "start": 651290, "end": 652981, "output_filename": "PDC6_sequence.xml"},
    {"accession_number": "BK006938.2", "start": 607304, "end": 610081, "output_filename": "x_PDC2_expression_gene.xml"},
]

# Perform BLAST search for each sequence
print("wait BLAST is going on....")
for seq_info in sequences_to_search:
    # Fetch the sequence from NCBI using accession number
    sequence = fetch_sequence(seq_info["accession_number"])

    # Perform BLAST search with the extracted subsequence
    blast_search(sequence, seq_info["start"], seq_info["end"], seq_info["output_filename"])
print(" BLAST COMPLETED ")

"""                                                OUTPUT OF THIS FILE
This file would generate the four files PDC1_sequence.xml,PDC5_sequence.xml,PDC6_sequence.xml,x_PDC2(expression_gene).xml in the xml format,by using the given file and search in the NCBI database.
"""