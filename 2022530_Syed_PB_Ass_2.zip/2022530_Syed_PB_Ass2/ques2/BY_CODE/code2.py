from Bio import SeqIO  # Importing SeqIO module from Biopython for reading sequence files
from Bio.Blast import NCBIXML  # Importing NCBIXML module from Biopython for parsing BLAST XML results
from collections import defaultdict  # Importing defaultdict from collections module for handling dictionaries
from Bio.Seq import Seq  # Importing Seq module from Biopython for working with sequences

# List to store processed strain names
storage = []

# Function to process BLAST results and identify SNPs
def main(sequences_to_search):
    """
    Process BLAST results to identify SNPs and strains with mutations.

    :param sequences_to_search: List of dictionaries containing input and output filenames.
    :return: None
    """
    print("Files are being processed...")
    for sequence_info in sequences_to_search:
        input_filename = sequence_info["input_filename"]   # Input BLAST XML file
        output_filename = sequence_info["output_filename"] # Output filenames for SNP and strain files
        strain_mutations = defaultdict(list)  # Dictionary to store strains with mutations
        
        with open(input_filename, "r") as blast_result_file:
            blast_records = NCBIXML.parse(blast_result_file)  # Parsing BLAST XML results
            
            snp_dict = defaultdict(list)  # Dictionary to store SNPs based on position
            
            # Iterate through BLAST records
            for record in blast_records:  
                for alignment in record.alignments:
                    for hsp in alignment.hsps:
                        percent_identity = (hsp.identities / hsp.align_length) * 100
                        
                        # Check if alignment has high identity but not 100%
                        if percent_identity > 98.9 and percent_identity < 99: # I used percent identity to fetch the result of min SNP,But it can be change
                            query_sequence = hsp.query
                            reference_sequence = hsp.sbjct
                            
                            # Identify SNPs
                            for pos in range(len(query_sequence)):
                                query_base = query_sequence[pos]
                                reference_base = reference_sequence[pos]
                                
                                #  Leaving hyphens   as they dont count in SNP
                                if query_base == '-':
                                    continue
                                if reference_base == '-':
                                    continue
                                
                                # Check if position is a SNP
                                if query_base != reference_base:
                                    mutation = f"{query_base}->{reference_base}"
                                    snp_dict[pos + 1].append({
                                        "subject": alignment.title,
                                        "mutation": mutation
                                    })
                                    strain_mutations[alignment.title].append((pos + 1, mutation))
    
            # Write SNP information to output file
            with open(f"{output_filename}_SNPS.txt", "w") as output_file:
                for pos, snps in snp_dict.items():
                    output_file.write(f"Position {pos}:\n")
                    for snp in snps:
                        output_file.write(f"  Subject: {snp['subject']}, Mutation: {snp['mutation']}\n")
                    output_file.write("\n")
            
            # Write strains with mutations and their changes to a file
            with open(f"{output_filename}_strains.txt", "w") as strains_file:
                strains_file.write("Strains with mutations:\n")
                for strain, mutations in strain_mutations.items():
                    strains_file.write(f"{strain}:\n")
                    storage.append(strain)
                    for pos, mutation in mutations:
                        strains_file.write(f"  Position {pos}: {mutation}\n")
                    
                    # Save nucleotide sequences of strains with mutations
    
# Function to extract nucleotide sequences of strains with mutations
def main1(sequences_to_search):
    """
    Extract nucleotide sequences of strains with mutations.

    :param sequences_to_search: List of dictionaries containing input and output filenames.
    :return: None
    """
    for sequence_info in sequences_to_search:
        input_filename = sequence_info["input_filename"]   # Input BLAST XML file
        output_filename = sequence_info["output_filename"] # Output filename for nucleotide sequences
        filename = sequence_info["output_filename"]
        strain_mutations = defaultdict(list)  # Dictionary to store strains with mutations
        
        with open(input_filename, "r") as blast_result_file:
            blast_records = NCBIXML.parse(blast_result_file)  # Parsing BLAST XML results
            
            snp_dict = defaultdict(list)  # Dictionary to store SNPs based on position
            i = 0
            # Iterate through BLAST records
            for record in blast_records:  
                for alignment in record.alignments:
                    for hsp in alignment.hsps:
                        percent_identity = (hsp.identities / hsp.align_length) * 100
                        # Check if alignment corresponds to a strain with mutations
                        if alignment.title in storage and percent_identity > 98.9 and percent_identity < 99 :
                            with open (f"{filename}_{i}.fasta","w") as file:
                                file.write(f">{alignment.title}\n")
                                file.write("")
                                query_seq = Seq(hsp.query)
                                query_reverse_complement = str(query_seq.reverse_complement())
                                file.write(query_reverse_complement)
                                i += 1


   

sequences_to_search = [
    {"input_filename":"PDC1_sequence.xml","output_filename": "PDC1/PDC1","filename":"PDC1/PDC1_SNPS_NUCLEOTIDE"},
    {"input_filename":"x_PDC2_expression_gene.xml","output_filename": "PDC2/PDC2","filename":"x_PDC2/PDC2_SNPS_NUCLEOTIDE"},
    {"input_filename":"PDC5_sequence.xml","output_filename": "PDC5/PDC5","filename":"PDC5/PDC5_SNPS_NUCLEOTIDE"},
    {"input_filename":"PDC6_sequence.xml","output_filename": "PDC6/PDC6","filename":"PDC6/PDC6_SNPS_NUCLEOTIDE"},
    # Add more sequences if needed
]



main(sequences_to_search)
main1(sequences_to_search)
print("Completed,refer folders PDC1,x_PDC2,PDC5,PDC6")


"""                                                      OUTPUT OF THIS
This file would generate the the three type of files in each of the folder.For example in PDC1 there would be file PDC1_SNPS.txt this file contains the 
location where SNPS are present in various strains and their change. PDC1_strains.txt contains all the strains with the most SNPS in them at most locations.
And there would be multiple third type of files those files would contain the Nucleotide sequence of PDC1 gene of different strains"""