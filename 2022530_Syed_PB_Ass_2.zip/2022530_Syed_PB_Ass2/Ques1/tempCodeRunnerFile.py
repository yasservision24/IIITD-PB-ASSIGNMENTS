 # seq_id = record.id if record.id else "<unknown id>"
            # seq_desc = record.description if record.description else "<unknown description>"
            
            # # Construct the header with ID and description
            # header = f">{seq_id} {seq_desc}\n"
            # f.write(header)