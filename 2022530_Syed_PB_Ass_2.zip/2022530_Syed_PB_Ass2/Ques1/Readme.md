
                                                        PB Assignment-2

Ques1. Access the NCBI database (https://www.ncbi.nlm.nih.gov/) and download the DNA sequence of the Saccharomyces cerevisiae PDC gene. (5 marks)

# Here I am doing based on yeast Saccharomyces cerevisiae Reference genome sequence(Strain S288C), So all data here is for this strain.

# Source -https://www.ncbi.nlm.nih.gov/datasets/genome/GCF_000146045.2/

    A total of six PDC genes has been identified in Saccharomyces cerevisiae, of which three are structural genes (PDC1, PDC5 and PDC6) and the remaining three are considered to be genes related to expression of PDC (PDC2, PDC3, PDC4) (Flikweert et al., 1996; Hohmann, 1997; Pohl, 1997; ter Schure et al., 1998). 
    Only PDC1 and PDC5 played an apparent role in sugar catabolism, with 80–90% and 10–20% of total PDC activity being attributed to these two genes, respectively, for glucose-grown biomass.
# Source- https://www.sciencedirect.com/topics/agricultural-and-biological-sciences/pyruvate-decarboxylase#:~:text=A%20total%20of%20six%20PDC,et%20al.%2C%201998.

    PDC1, PDC5, and PDC6 encode three different isozymes of pyruvate decarboxylase, an enzyme which catalyzes the degradation of pyruvate into acetaldehyde and carbon dioxide.
    Transcription of PDC6 is dramatically induced under conditions of sulfur limitation, suggesting that it has a role during sulfur-limited growth . Consistent with this, the PDC6 gene encodes fewer sulfur-containing amino acids than does either PDC1 or PDC5 (6 codons vs. 17 or 18, respectively) 
    Thus PDC6 is weeakly expressed
# Source -https://www.yeastgenome.org/locus/S000003319#reference

    Thus we can say, In the yeast, Saccharomyces cerevisiae, pyruvate decarboxylase (Pdc) is encoded predominantly by  two isogenes PDC1 and PDC5. 
    Only PDC1 and PDC5 played an apparent role in sugar catabolism, with 80–90% and 10–20% of total PDC activity being attributed to these two genes, respectively, for glucose-grown biomass.
    In the yeast, Saccharomyces cerevisiae, pyruvate decarboxylase (Pdc) is encoded by the two isogenes PDC1 and PDC5. 
# Source- https://pubmed.ncbi.nlm.nih.gov/10231381/#:~:text=In%20the%20yeast%2C%20Saccharomyces%20cerevisiae,a%20phenomenon%20called%20Pdc%20autoregulation.

# Source- https://www.sciencedirect.com/topics/agricultural-and-biological-sciences/pyruvate-decarboxylase#:~:text=A%20total%20of%20six%20PDC,et%20al.%2C%201998.

The term "isogenes" refers to genes within a single species that have similar sequences and functions but might differ slightly due to evolutionary processes such as gene duplication, mutation, or alternative splicing. Isogenes are essentially homologous genes within a species.







# PDC1
Major of three pyruvate decarboxylase isozymes; key enzyme in alcoholic fermentation; decarboxylates pyruvate to acetaldehyde; involved in amino acid catabolism; subject to glucose-, ethanol-, and autoregulation; activated by phosphorylation in response to glucose levels; N-terminally propionylated in vivo; protein tyrosine nitration on Tyr157 or Tyr344 inhibits activity and impairs fermentation.

PDC1 is located on the right arm of chromosome XII between TRX1 thioredoxin and STU2 microtubule polymerase; coding sequence is 1692 nucleotides long with 8 SNPSs, 4 of which lead to amino acid polymorphisms.

    PDC1 Location: Chromosome XII 232390..234081     #  /gene="PDC1"    #/locus_tag="YLR044C"   # /product="indolepyruvate decarboxylase 1


# Source- https://www.yeastgenome.org/locus/S000004034

# Source- https://www.ncbi.nlm.nih.gov/nuccore/BK006945.2/


# PDC5
Minor isoform of pyruvate decarboxylase; key enzyme in alcoholic fermentation, decarboxylates pyruvate to acetaldehyde, regulation is glucose- and ethanol-dependent, repressed by thiamine, involved in amino acid catabolism 

    PDC5 Location: Chromosome XII 410723..412414   #  /gene="PDC5"   #/locus_tag="YLR134W"    #/product="indolepyruvate decarboxylase 5"

# Source- https://www.yeastgenome.org/locus/S000004124

# Source- https://www.ncbi.nlm.nih.gov/nuccore/BK006945.2/



# PDC6
Minor isoform of pyruvate decarboxylase; decarboxylates pyruvate to acetaldehyde, involved in amino acid catabolism; transcription is glucose- and ethanol-dependent, and is strongly induced during sulfur limitation.

    PDC6 Location: Chromosome VII 651290..652981    #/gene="PDC6"  # /locus_tag="YGR087C"   # /product="indolepyruvate decarboxylase 6"   

# Source-https://www.yeastgenome.org/locus/S000003319

# Source-https://www.ncbi.nlm.nih.gov/nuccore/BK006941.2/



What are isoforms of a protein?
Different forms of a protein that may be produced from different GENES, or from the same gene by ALTERNATIVE SPLICING.

What are isoenzymes?
Ennzymes that catalyze the same type of reaction but are created by different genes and have different molecular shapes



    Now We will download the sequence of PDC1 and PDC5 gene from chromosome 12 and chromosome 7 of yeastSaccharomyces cerevisiae genome,using the accession no. BK006945.2(Chromosome 12) and accession no. BK006941.2(Chromosome 7).

    PDC1 Location: Chromosome XII 232390..234081                   # Source- https://www.ncbi.nlm.nih.gov/nuccore/BK006945.2/
    PDC5 Location: Chromosome XII 410723..412414                   # Source- https://www.ncbi.nlm.nih.gov/nuccore/BK006945.2/
    PDC6 Location: Chromosome VII 651290..652981                   # Source-https://www.ncbi.nlm.nih.gov/nuccore/BK006941.2/




# PDC1 TRANSLATED    # Source- https://www.ncbi.nlm.nih.gov/nuccore/BK006945.2/
        MSEITLGKYLFERLKQVNVNTVFGLPGDFNLSLLDKIYEVEGMR
        WAGNANELNAAYAADGYARIKGMSCIITTFGVGELSALNGIAGSYAEHVGVLHVVGVP
        SISAQAKQLLLHHTLGNGDFTVFHRMSANISETTAMITDIATAPAEIDRCIRTTYVTQ
        RPVYLGLPANLVDLNVPAKLLQTPIDMSLKPNDAESEKEVIDTILALVKDAKNPVILA
        DACCSRHDVKAETKKLIDLTQFPAFVTPMGKGSIDEQHPRYGGVYVGTLSKPEVKEAV
        ESADLILSVGALLSDFNTGSFSYSYKTKNIVEFHSDHMKIRNATFPGVQMKFVLQKLL
        TTIADAAKGYKPVAVPARTPANAAVPASTPLKQEWMWNQLGNFLQEGDVVIAETGTSA
        FGINQTTFPNNTYGISQVLWGSIGFTTGATLGAAFAAEEIDPKKRVILFIGDGSLQLT
        VQEISTMIRWGLKPYLFVLNNDGYTIEKLIHGPKAQYNEIQGWDHLSLLPTFGAKDYE
        THRVATTGEWDKLTQDKSFNDNSKIRMIEIMLPVFDAPQNLVEQAKLTAATNAKQ

# PDC5 TRANSLATED   # Source- https://www.ncbi.nlm.nih.gov/nuccore/BK006945.2/
        MSEITLGKYLFERLSQVNCNTVFGLPGDFNLSLLDKLYEVKGMR
        WAGNANELNAAYAADGYARIKGMSCIITTFGVGELSALNGIAGSYAEHVGVLHVVGVP
        SISSQAKQLLLHHTLGNGDFTVFHRMSANISETTAMITDIANAPAEIDRCIRTTYTTQ
        RPVYLGLPANLVDLNVPAKLLETPIDLSLKPNDAEAEAEVVRTVVELIKDAKNPVILA
        DACASRHDVKAETKKLMDLTQFPVYVTPMGKGAIDEQHPRYGGVYVGTLSRPEVKKAV
        ESADLILSIGALLSDFNTGSFSYSYKTKNIVEFHSDHIKIRNATFPGVQMKFALQKLL
        DAIPEVVKDYKPVAVPARVPITKSTPANTPMKQEWMWNHLGNFLREGDIVIAETGTSA
        FGINQTTFPTDVYAIVQVLWGSIGFTVGALLGATMAAEELDPKKRVILFIGDGSLQLT
        VQEISTMIRWGLKPYIFVLNNNGYTIEKLIHGPHAEYNEIQGWDHLALLPTFGARNYE
        THRVATTGEWEKLTQDKDFQDNSKIRMIEVMLPVFDAPQNLVKQAQLTAATNAKQ

# PDC6 TRANSLATED   # Source-https://www.ncbi.nlm.nih.gov/nuccore/BK006941.2/
        MSEITLGKYLFERLKQVNVNTIFGLPGDFNLSLLDKIYEVDGLR
        WAGNANELNAAYAADGYARIKGLSVLVTTFGVGELSALNGIAGSYAEHVGVLHVVGVP
        SISAQAKQLLLHHTLGNGDFTVFHRMSANISETTSMITDIATAPSEIDRLIRTTFITQ
        RPSYLGLPANLVDLKVPGSLLEKPIDLSLKPNDPEAEKEVIDTVLELIQNSKNPVILS
        DACASRHNVKKETQKLIDLTQFPAFVTPLGKGSIDEQHPRYGGVYVGTLSKQDVKQAV
        ESADLILSVGALLSDFNTGSFSYSYKTKNVVEFHSDYVKVKNATFLGVQMKFALQNLL
        KVIPDVVKGYKSVPVPTKTPANKGVPASTPLKQEWLWNELSKFLQEGDVIISETGTSA
        FGINQTIFPKDAYGISQVLWGSIGFTTGATLGAAFAAEEIDPNKRVILFIGDGSLQLT
        VQEISTMIRWGLKPYLFVLNNDGYTIEKLIHGPHAEYNEIQTWDHLALLPAFGAKKYE
        NHKIATTGEWDALTTDSEFQKNSVIRLIELKLPVFDAPESLIKQAQLTAATNAKQ


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

I have also dowbloaded the seqeunces of PDC2,PDC3,PDC4 are genes related to expression of PDC1,PDC2 and PDC6.

PDC2 
Transcription factor for thiamine-regulated genes; required for expression of the two isoforms of pyruvate decarboxylase (PDC1 and PDC5) along with thiamine biosynthetic genes; binds a DNA sequence in the PDC5 promoter; mutant fails to grow on 2% glucose and thus is scored as inviable under standard conditions

PDC2 Location: Chromosome IV 607304..610081      /gene="PDC2"   /locus_tag="YDR081C"  /product="Pdc2p"
Accession no- BK006938.2
# Source- https://www.yeastgenome.org/locus/S000002488

# Source- https://www.ncbi.nlm.nih.gov/nuccore/BK006938.2/

# Trasnlated PDC2    # Source- https://www.ncbi.nlm.nih.gov/nuccore/BK006938.2/
            MLSIQQRYNICLMAERHPKWTQLELAKWAYETFQLPKIPSQGTI
            SRLLARKSTYMNCKEHEKDANRLRKPNNLLVRKILQEWISQSLWNGIPITSPIIQDTA
            QAVWHRIPAEHREGNGSFSYKWISNFLSKMDVNISVLDEELPKTPKVWTFEERDVLKA
            YFSKIPPKDLFTLDEAFLSYNLPLDYAQYEASSIQRRIEVATVMLCSNLDGSEKLKPV
            VVGKYDSYKSFRNYFPNEPNDPVSQSMLGTKMAKKFDISYHSNRKAWLTSNLFHNWLV
            RWDKRLVAVNRKIWIVLDDSCCHRIINLRLQNIKLVYTSSNSKFLPFNWGVWDEFKTR
            YRIQQYQALIDLQNRISKNIQNKNKSERNECIPNGKKCLISFEQSQLTMSNAFKFIKK
            AWDDIPVDAIKANWKSSGLLPPEMIHLNENVSMAFKKNEVLESVLNRLCDEYYCVKKW
            EYEMLLDLNIENKNTNFLSTEELVESAIVEPCEPDFDTAPKGNEVHDDNFDVSVFANE
            DDNNQNHLSMSQASHNPDYNSNHSNNAIENTNNRGSNNNNNNNGSSNNINDNDSSVKY
            LQQNTVDNSTKTGNPGQPNISSMESQRNSSTTDLVVDGNYDVNFNGLLNDPYNTMKQP
            GPLDYNVSTLIDKPNLFLSPDLDLSTVGVDMQLPSSEYFSEVFSSAIRNNEKAASDQN
            KSTDELPSSTAMANSNSITTALLESRNQAQPFDVPHMNGLLSDTSKSGHSVNSSNAIS
            QNSLNNFQHNSASVAEASSPSITPSPVAINSTGAPARSIISAPIDSNSSASSPSALEH
            LEGAVSGMSPSSTTILSNLQTNINIAKSLSTIMKHAESNEISLTKETINELNFNYLTL
            LKRIKKTRKQLNSESIKINSKNAQDHLETLLSGAAAAAATSANNLDLPTGGSNLPDSN
            NLHLPGNTGFF

I was not able to find the relible resource for the PDC3 AND PDC6




BASIC FLOW 

    First I studied about the PDC gene of  saccharomyces cerevisiae, I came to know that there are 2 main types of PDC  gens,Structural and expressional.
    PDC1,PDC5,PDC6 are structural  while PDC2,PDC3,PDC5  control expression of structural genes .
    # Source- https://www.sciencedirect.com/topics/agricultural-and-biological-sciences/pyruvate-decarboxylase#:~:text=A%20total%20of%20six%20PDC,et%20al.%2C%201998.

    Then I identified the chromosomes and the seqeunce on which these PDCs genes are present in the saccharomyces cerevisiae  Reference genome sequence(Strain S288C) Databse in NCBI database.

    After identifying the chromosome and the sequence I wrote the Pyhton code to fetch the fasta file using Accesion no and passed the  begining and end index of the sequence as argument.

    Moreover The PDC1,PDC6,PDC2 genes were present in complementary form as it can be seen on the description on NCBI website so I used the reverse complement of their sequence to fetech the correct sequence,Then I verified using # https://www.yeastgenome.org/

    I was able to find the sequences of all structural genes(PDC1,PDC5,PDC6)  but for expression gene I was able to find only (PDC2) gene.
















