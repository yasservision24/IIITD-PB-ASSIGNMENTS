
# Here I am doing based on yeast Saccharomyces cerevisiae Reference genome sequence(Strain S288C), So all data here is for this strain.
# So here we say this as a query gene or say Normal gene.

# Source -https://www.ncbi.nlm.nih.gov/datasets/genome/GCF_000146045.2/
"""  A total of six PDC genes has been identified in Saccharomyces cerevisiae, of which three are structural genes (PDC1, PDC5 and PDC6) and the remaining three are considered to be genes related to expression of PDC (PDC2, PDC3, PDC4) (Flikweert et al., 1996; Hohmann, 1997; Pohl, 1997; ter Schure et al., 1998). 
    Only PDC1 and PDC5 played an apparent role in sugar catabolism, with 80–90% and 10–20% of total PDC activity being attributed to these two genes, respectively, for glucose-grown biomass.
# Source- https://www.sciencedirect.com/topics/agricultural-and-biological-sciences/pyruvate-decarboxylase#:~:text=A%20total%20of%20six%20PDC,et%20al.%2C%201998.
"""


from Bio import Entrez, SeqIO 
# Bio: This library provides tools for biological data processing, including accessing biological databases like NCBI and parsing sequence data.
# Entrez: This module from the Bio library provides functions for accessing the NCBI Entrez services, such as fetching sequence data from the NCBI databases.
# SeqIO: This module from the Bio library is used for reading and writing sequence data in various formats, such as FASTA.
def download_sequence(accession_number, start, end): #defining functions
    Entrez.email = "syed22530@iiitd.ac.in"  
    handle = Entrez.efetch(db="nucleotide", id=accession_number, seq_start=start, seq_stop=end, rettype="fasta", retmode="text")
    record = SeqIO.read(handle, "fasta")
    handle.close()
    sequence = record.seq
    record.seq = sequence

    return record
# For some genes NCBI gives Complementary strand means Antisense strand,this strand does not code for Amino acid,it is template/coding strand
# so we Take reverse complement so that we now have the Sense strand
from Bio import SeqIO

from Bio import SeqIO

from Bio import SeqIO

def save_sequence(record, filename):
    with open(filename, "w") as f:
        if filename == "PDC5_sequence.fasta":
            SeqIO.write(record, f, "fasta")   
        else:
            # Create a reverse complement record and set its metadata
            reverse_record = record.reverse_complement()
            reverse_record.id = record.id
            reverse_record.description = record.description
            
            # Write the reverse complement of the sequence using SeqIO.write
            SeqIO.write(reverse_record, f, "fasta")
    print(f"Sequence saved to {filename}")

# Example usage:
# save_sequence(record, "PDC5_sequence.fasta")


# Example usage:
# save_sequence(record, "PDC5_sequence.fasta")

# Example usage:
# save_sequence(record, "PDC5_sequence.fasta")

"""Now We will download the sequence of PDC1 and PDC5 gene from chromosome 12 and chromosome 7 of yeast Saccharomyces cerevisiae Reference genome sequence(Strain S288C),using the accession no. BK006945.2(Chromosome 12) and accession no. BK006941.2(Chromosome 7).

PDC1 Location: Chromosome XII 232390..234081   accession_no-BK006945.2   # Source- https://www.ncbi.nlm.nih.gov/nuccore/BK006945.2/
PDC5 Location: Chromosome XII 410723..412414   accession_no-BK006945.2   # Source- https://www.ncbi.nlm.nih.gov/nuccore/BK006945.2/
PDC6 Location: Chromosome VII 651290..652981   accession_no-BK006941.2   # Source-https://www.ncbi.nlm.nih.gov/nuccore/BK006941.2/
PDC2 Location: Chromosome IV 607304..610081    accession_no-BK006938.2   # Source- https://www.ncbi.nlm.nih.gov/nuccore/BK006938.2/  
"""
# PDC1,PDC5,PDC6 ARE THE STRUCTURAL GENES
# WHILE THE PDC2,PDC3,PDC5 ARE EXPRESSION GENES WHICH CONTROL THE EXPRESSION OF STRUCTURAL GENES, FROM THEM I WAS ABLE TO FIND ONLY PDC2 

if __name__ == "__main__":
    sequences = [

        {"accession_number": "BK006945.2", "start": 232390, "end": 234081, "output_filename": "PDC1_sequence.fasta"},
        {"accession_number": "BK006945.2", "start": 410723, "end": 412414, "output_filename": "PDC5_sequence.fasta"},
        {"accession_number": "BK006941.2", "start": 651290, "end": 652981, "output_filename": "PDC6_sequence.fasta"},
        {"accession_number": "BK006938.2", "start": 607304, "end": 610081, "output_filename": "x_PDC2(expression_gene).fasta"},
        
        ]

    for seq_info in sequences:
        sequence_record = download_sequence(seq_info["accession_number"], seq_info["start"], seq_info["end"])
        save_sequence(sequence_record, seq_info["output_filename"])
        
        
        
""" PDC1, PDC5, and PDC6 encode three different isozymes of pyruvate decarboxylase, an enzyme which catalyzes the degradation of pyruvate into acetaldehyde and carbon dioxide.
    Transcription of PDC6 is dramatically induced under conditions of sulfur limitation, suggesting that it has a role during sulfur-limited growth . Consistent with this, the PDC6 gene encodes fewer sulfur-containing amino acids than does either PDC1 or PDC5 (6 codons vs. 17 or 18, respectively) 
# Source -https://www.yeastgenome.org/locus/S000003319#reference"""


"""In the yeast, Saccharomyces cerevisiae, pyruvate decarboxylase (Pdc) is encoded by the two isogenes PDC1 and PDC5. 
# Source- https://pubmed.ncbi.nlm.nih.gov/10231381/#:~:text=In%20the%20yeast%2C%20Saccharomyces%20cerevisiae,"""


"""
BASIC FLOW 

    First I studied about the PDC gene of  saccharomyces cerevisiae, I came to know that there are 2 main types of PDC  gens,Structural and expressional.
    PDC1,PDC5,PDC6 are structural  while PDC2,PDC3,PDC5  control expression of structural genes .
    # Source- https://www.sciencedirect.com/topics/agricultural-and-biological-sciences/pyruvate-decarboxylase#:~:text=A%20total%20of%20six%20PDC,et%20al.%2C%201998.

    Then I identified the chromosomes and the seqeunce on which these PDCs genes are present in the saccharomyces cerevisiae  Reference genome sequence(Strain S288C)Databse in NCBI database.

    After identifying the chromosome and the sequence I wrote the Pyhton code to fetch the fasta file using Accesion no and passed the  begining and end index of the sequence as argument.

    I was able to find the sequences of all structural genes(PDC1,PDC5,PDC6)  but for expression gene I was able to find only (PDC2) gene."""
    
    
    
"""                                                         OUTPUT OF THIS FILE
This script would generate the three four files of PDC genes by name PDC1_sequence.fasta,PDC5_sequence.fasta,PDC6_sequence.fasta,x_PDC2(expression_gene).fasta in fasta format.
The sequence is of the Sense Strand of the gene

"""
