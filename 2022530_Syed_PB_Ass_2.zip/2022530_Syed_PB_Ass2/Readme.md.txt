Background:
Pyruvate Decarboxylase Gene is key for increasing CO2 production by yeast and may have a role in improving bread leavening and wine making.

Access the NCBI database (https://www.ncbi.nlm.nih.gov/) and download the DNA sequence of the Saccharomyces cerevisiae PDC gene. (5 marks)

Use BLAST (Basic Local Alignment Search Tool) to compare the PDC gene sequence across different Saccharomyces cerevisiae strains and identify SNPs. (5 marks)

Use an translation tool (e.g., ExPASy Translate tool) to translate the normal and SNP-containing PDC gene sequences into amino acid sequences. (5 marks)

Select a SNP within the PDC gene. Utilize tools like SIFT (Sorting Intolerant From Tolerant) or PolyPhen (Polymorphism Phenotyping) to predict the impact of the SNP on the PDC protein function. (5 marks)



Evaluation Criteria
Understanding of the biological concepts and bioinformatics tools.
Accuracy in data retrieval and analysis
Depth of analysis in the impact of SNPs on protein function.
Quality and clarity of writing.
Proper citation of sources and presentation of data.
Submission
Write code, read me file and other relevant with project details using a text editor.
Ensure all relevant files are included and organized properly.
Save it in your project folder with the format: yourname_your-rollnumber.
Compress the folder into a zip file and upload on Google Classroom.