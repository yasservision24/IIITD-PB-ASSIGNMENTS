QUES3-Use an translation tool (e.g., EXPASY
   Translate tool) to translate the normal and SNP-containing PDC gene sequences into amino acid sequences. (5 marks)

    
    Translation, as related to genomics, is the process through which information encoded in messenger RNA (mRNA) directs the addition of amino acids during protein synthesis. Translation takes place on ribosomes in the cell cytoplasm, where mRNA is read and translated into the string of amino acid chains that make up the synthesized protein
    
    A codon is a DNA or RNA sequence of three nucleotides (a trinucleotide) that forms a unit of genomic information encoding a particular amino acid or signaling the termination of protein synthesis (stop signals). There are 64 different codons: 61 specify amino acids and 3 are used as stop signals.
    The double helix of a DNA molecule has two anti-parallel strands; with the two strands having three reading frames each, there are six(6) possible frame translations.

    What is the EXPASY tool used for?
    It translates DNA sequences into amino acid sequences.
    
    A wobble base pair is a pairing between two nucleotides in RNA molecules that does not follow Watson-Crick base pair rules.
    So there are mutliple codons which codes for same Amino Acid.
    The genetic code is described as degenerate, or redundant, because a single amino acid may be coded for by more than one codon.
#   Source -https://www.nature.com/scitable/definition/genetic-code-13/#:~:text=Although%20each%20codon%20is%20specific,by%20more%20than%20one%20codon.

As there are 6 open reading frame in DNA so there would be 6 possible translation. Three from 5'-3'  and three from 3'-5'.
So EXPASY   would give 6 possible frames.

Basic flow

    As there would be multiple possible strains,So I have taken only few of them and translated them into amino acid sequences.

    I have used EXPASY
       Translate tool to translate the normal and SNP-containing PDC gene sequences into amino acid sequences.

    I have taken the normal and SNP-containing PDC gene sequences from the GenBank database.

    I have used the EXPASY
       Translate tool to translate the normal and SNP-containing PDC gene sequences into amino acid sequences.

    I have compared the amino acid sequences of the normal and SNP-containing PDC gene sequences to determine the differences between them.
    
    Source From which I got the nucleotide seqeunces  of the SNP contaning genes


  S.cerevisiae PDC1 gene, mutant pdc1-8
#  https://www.ncbi.nlm.nih.gov/nucleotide/X77312.1?report=genbank&log$=nuclalign&blast_rank=1&RID=Z5TH686F016&from=1&to=1692 

  S.cerevisiae PDC1 gene, mutant pdc1-14
# https://www.ncbi.nlm.nih.gov/nucleotide/X77311.1?report=genbank&log$=nuclalign&blast_rank=2&RID=Z5TH686F016

  Saccharomyces cerevisiae strain XXYS1.4 genome assembly, chromosome: 12  
# https://www.ncbi.nlm.nih.gov/nucleotide/LR813613.2?report=genbank&log$=nuclalign&blast_rank=1&RID=Z5TFKSR4013&from=392934&to=394625

  Saccharomyces cerevisiae strain JXXY16.1 genome assembly, chromosome: 12
# https://www.ncbi.nlm.nih.gov/nucleotide/LR813579.2?report=genbank&log$=nuclalign&blast_rank=2&RID=Z5TFKSR4013&from=395162&to=396853


WEB METHOD

I have creeated Three folder:

Folder Normal
    
    Contains translation of Normal PDC1,PDC5,PDC6,PDC2 gene. Nomral refers to the gene of reference gene,Saccharomyces cerevisiae Strain S288c,also I have attached the screenshot while translating using EXPASY
      .

Folder SNP genes

    Contains translation of SNP containing PDC genes

Folder xtra strains

    Contains translation of some more PDC genes of different strains strains

BY_CODE


    Translation of DNA Sequences:

    The script reads input DNA sequences from FASTA files.
    For each DNA sequence, it attempts to translate it into a protein sequence using  ExPASy's translation method.
    If it fails then it uses Biopython's translation method.
    Translated protein sequences are then stored in output files in FASTA format, with the prefix "translated_" added to the original input file name.
    These translated protein sequences are saved in a specified output directory (Normal_translated_sequences).
    Identification of SNPs:

    The script reads pre-existing BLAST result files containing alignment information.
    It iterates through the alignments and identifies SNPs by comparing the query (input) sequence to the subject (reference) sequence.
    SNPs are recorded based on their position and the mutation observed (e.g., A->C).
    SNP information is saved in separate output files (_SNPS.txt) for each input DNA sequence, containing details about the position, subject, and mutation observed.
    Additionally, strains with mutations and their respective changes are saved in another output file (_strains.txt).
    Handling Different Genes:

    The script includes functionality to handle DNA sequences from different genes, each stored in separate folders (PDC1, PDC2, PDC5, PDC6).
    It translates and stores protein sequences for each gene separately, ensuring organization and clarity in the output.
    Error Handling and Reporting:

    The script includes error handling mechanisms to address cases where translation fails using both Biopython and ExPASy methods.
    Detailed error messages are printed to notify users of translation failures, aiding in troubleshooting.



