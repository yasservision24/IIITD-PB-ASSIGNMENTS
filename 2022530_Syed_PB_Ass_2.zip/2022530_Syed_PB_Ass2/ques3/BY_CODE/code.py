from Bio import SeqIO
from Bio.Seq import Seq
from Bio import ExPASy
import os

# Get the current directory of the script
current_directory = os.path.dirname(__file__)

# Define the path to the folder containing DNA sequence files
folder_a_path = os.path.abspath(os.path.join(current_directory, '..', '..', 'Ques1'))

# Define a function to translate DNA sequences and store translated protein sequences
def translate_and_store(input_files, output_dir):
    """
    Translate DNA sequences to protein sequences and store them in the specified output directory.

    Args:
        input_files (list): List of input file names containing DNA sequences.
        output_dir (str): Output directory where translated protein sequences will be stored.
    """
    # Translate and store protein sequences for each input file
    for input_file in input_files:
        # Construct the full path to the input file
        file1_path = os.path.join(folder_a_path, input_file)
        
        # Read DNA sequences from the FASTA file
        dna_records = SeqIO.parse(file1_path, "fasta")
        
        # Translate each DNA sequence and store translated protein sequences
        for record in dna_records:
            # Attempt translation using Biopython's translation method
            try:
                protein_sequence = translate_with_stops(record.seq)
                method = 'Biopython'
            except Exception as biopython_error:
                # If Biopython translation fails, attempt ExPASy translation
                try:
                    expasy_handle = ExPASy.get_sprot_raw(str(record.seq.translate(to_stop=True)))
                    protein_record = SeqIO.read(expasy_handle, "swiss")
                    protein_sequence = protein_record.seq
                    method = 'ExPASy'
                except Exception as expasy_error:
                    print(f"Both Biopython and ExPASy translation failed for sequence {record.id}: {expasy_error}")
                    continue  # Skip this sequence if both translation methods fail
                    
            # Prepare output filename
            output_filename = os.path.join(output_dir, f"translated_{input_file}")
            
            # Write translated protein sequence to output file in FASTA format
            with open(output_filename, 'w') as f:
                f.write(f">{input_file}_translated_\n")
                f.write(str(protein_sequence) + "\n")
                
            print(f"Translated sequence saved to: {output_filename}")

def translate_with_stops(dna_seq):
    """
    Translate DNA sequence to protein sequence while preserving stop codons.

    Args:
        dna_seq (Seq): DNA sequence to be translated.

    Returns:
        Seq: Translated protein sequence.
    """
    translated_seq = ""
    for i in range(0, len(dna_seq), 3):
        codon = dna_seq[i:i+3]
        if len(codon) == 3:
            amino_acid = codon.translate(table=1)
            if amino_acid == "*":
                translated_seq += "-"  # Preserve stop codon as "-"
            else:
                translated_seq += amino_acid
    return Seq(translated_seq)

# Input list of FASTA files containing DNA sequences
input_files = ['PDC1_sequence.fasta', 'PDC5_sequence.fasta','PDC6_sequence.fasta','x_PDC2(expression_gene).fasta']

# Output directory for translated protein sequences
output_dir = 'Normal_translated_sequences'

# Create output directory if it doesn't exist
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# Translate and store protein sequences
translate_and_store(input_files, output_dir)

# Define paths to folders containing DNA sequence files for different genes
folder_a_path1 = os.path.abspath(os.path.join(current_directory, '..', '..', 'ques2', 'BY_CODE', 'PDC1'))
folder_a_path2 = os.path.abspath(os.path.join(current_directory, '..', '..', 'ques2', 'BY_CODE', 'PDC2'))
folder_a_path5 = os.path.abspath(os.path.join(current_directory, '..', '..', 'ques2', 'BY_CODE', 'PDC5'))
folder_a_path6 = os.path.abspath(os.path.join(current_directory, '..', '..', 'ques2', 'BY_CODE', 'PDC6'))

def translate_and_store1(input_files, output_dir):
    """
    Translate DNA sequences for different genes and store translated protein sequences.

    Args:
        input_files (list): List of input file names containing DNA sequences.
        output_dir (str): Output directory where translated protein sequences will be stored.
    """
    for input_file in input_files:
        # Determine the gene type based on the input file name
        # There could be a chance of exceptions here as if we chnage the percent ideentitity in the ques2 code ,some of these files may not formso,be carefull 
        if input_file[3] == '1':
            file1_path = os.path.join(folder_a_path1, input_file)
        elif input_file[3] == '2':
            file1_path = os.path.join(folder_a_path2, input_file)
        elif input_file[3] == '5':
            file1_path = os.path.join(folder_a_path5, input_file)
        elif input_file[3] == '6':
            file1_path = os.path.join(folder_a_path6, input_file)
        
        # Read DNA sequences from FASTA file
        dna_records = SeqIO.parse(file1_path, "fasta")

        for record in dna_records:
            try:
                # Perform translation using Biopython's translation method
                protein_sequence = translate_with_stops(record.seq)
                method = 'Biopython'
            except Exception as biopython_error:
                # If Biopython translation fails, attempt ExPASy translation
                try:
                    expasy_handle = ExPASy.get_sprot_raw(str(record.seq.translate(to_stop=True)))
                    protein_record = SeqIO.read(expasy_handle, "swiss")
                    protein_sequence = protein_record.seq
                    method = 'ExPASy'
                except Exception as expasy_error:
                    print(f"Both Biopython and ExPASy translation failed for sequence {record.id}: {expasy_error}")
                    continue  # Skip this sequence if both translation methods fail

            # Prepare output filename
            output_filename = os.path.join(output_dir, f"translated_{input_file}")

            # Write translated protein sequence to output file in FASTA format
            with open(output_filename, 'w') as f:
                f.write(f">{input_file}_{record.description}_translated_\n")
                f.write(str(protein_sequence) + "\n")

            print(f"Translated sequence saved to: {output_filename}")

# Input list of FASTA files containing DNA sequences for different genes


# There could be a chance of exceptions here as if we chnage the percent ideentitity in the ques2 code ,some of these files may not formso,be carefull
input_files1 = ['PDC1_0.fasta', 'PDC1_1.fasta', 'PDC1_2.fasta',
                'PDC2_0.fasta', 'PDC2_1.fasta', 'PDC2_2.fasta', 'PDC2_3.fasta', 'PDC2_4.fasta',
                'PDC2_5.fasta', 'PDC2_6.fasta', 'PDC2_7.fasta', 'PDC2_8.fasta', 'PDC2_9.fasta',
                'PDC5_0.fasta', 'PDC5_1.fasta', 'PDC5_2.fasta', 'PDC5_3.fasta',
                'PDC6_0.fasta', 'PDC6_1.fasta', 'PDC6_2.fasta', 'PDC6_3.fasta', 'PDC6_4.fasta',
                'PDC6_5.fasta', 'PDC6_6.fasta', 'PDC6_7.fasta', 'PDC6_8.fasta', 'PDC6_9.fasta',
                'PDC6_10.fasta', 'PDC6_11.fasta', 'PDC6_12.fasta', 'PDC6_13.fasta', 'PDC6_14.fasta']

# Output directory for translated protein sequences
output_dir1 = 'SNP_translated_sequences'

# Create output directory if it doesn't exist
if not os.path.exists(output_dir1):
    os.makedirs(output_dir1)

# Translate and store protein sequences
translate_and_store1(input_files1, output_dir1)


"""                                              OUTPUT OF THIS
This file would generate the translated sequence of Normal PDC genes And SNP containg PDC genes in two different folders"""