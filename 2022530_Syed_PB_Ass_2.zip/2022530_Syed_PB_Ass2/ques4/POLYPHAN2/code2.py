from Bio import SeqIO
from Bio.Blast import NCBIXML
from collections import defaultdict
from Bio.Seq import Seq

# Function to process BLAST results and identify single_amino_acid_changes
def main(sequences_to_search):
    """
    Process BLAST results to identify single_amino_acid_changes and strains with mutations.

    :param sequences_to_search: List of dictionaries containing input and output filenames.
    :return: None
    """
    print("Files are being processed...")
    for sequence_info in sequences_to_search:
        input_filename = sequence_info["input_filename"]   # Input BLAST XML file
        output_filename = sequence_info["output_filename"] # Output filenames for single_amino_acid_change and strain files
        strain_mutations = defaultdict(list)  # Dictionary to store strains with mutations
        
        with open(input_filename, "r") as blast_result_file:
            blast_records = NCBIXML.parse(blast_result_file)  # Parsing BLAST XML results
            
            # Iterate through BLAST records
            for record in blast_records:  
                for alignment in record.alignments:
                    for hsp in alignment.hsps:
                        percent_identity = (hsp.identities / hsp.align_length) * 100
                        
                        # Check if alignment has high identity but not 100%
                        if percent_identity >99.5 and percent_identity <99.9:
                            query_sequence = Seq(hsp.query)
                            reference_sequence = Seq(hsp.sbjct)
                            
                            
                            single_amino_acid_change_count = 0
                            for pos in range(len(query_sequence)):
                                query_aa = query_sequence[pos]
                                reference_aa = reference_sequence[pos]
                                
                                # Leaving hyphens as they don't count in single_amino_acid_change
                                if query_aa == '-':
                                    continue
                                if reference_aa == '-':
                                    continue
                                
                                
                                if query_aa != reference_aa:
                                    mutation = f"{query_aa}->{reference_aa}"
                                    single_amino_acid_change_count += 1
                                    strain_mutations[alignment.title].append((pos + 1, mutation))
                                    break
                               # Exit loop after finding one mutation
    
        # Write information to output file for sequences with exactly one single_amino_acid_change
        with open(f"{output_filename}.txt", "w") as output_file:
            output_file.write("Sequences with ONE mutation:\n")
            for sequence_title, mutations in strain_mutations.items():
                output_file.write(f"{sequence_title}:\n")
                for pos, mutation in mutations:
                    output_file.write(f"Position {pos}: Mutation: {mutation}\n")
                output_file.write("\n")
    
    

sequences_to_search = [
    {"input_filename": "amino_PDC1.xml", "output_filename": "PDC1"},
    {"input_filename": "amino_PDC5.xml", "output_filename": "PDC5"},
    {"input_filename": "amino_PDC6.xml", "output_filename": "PDC6"},
    {"input_filename": "amino_PDC2.xml", "output_filename": "PDC2"}
]

main(sequences_to_search)

print("Completed")


"""                                              OUTPUT OF THIS
This file would read the files amino_PDC1.xml and so on and find the single amino acod substitution and return the result by writing it to the file PDC1,PDC2 and so on.
The files would contain the name of strain the change of amino acid and its position"""