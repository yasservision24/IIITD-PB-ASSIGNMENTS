Here I used the BLASTp tool of NCBI,BLASTP is the appropriate choice for comparing protein sequences against a protein sequence database, and it enables us to gain insights into the characteristics and relationships of the proteins under investigation.
Code1 is used to perform the BLASTp by using the amino acid sequences,and stored the result in the file files amino_PDC1.xml and so on.
By using the Code2,I read the amino_PDC1.xml  and so on.Then this code identifies the one amino acid mutation and its location and change,result is stored in PDC1.txt and so on.
Then I performed the prediction using the result obtained by code2 and POLYPHAN2 tool and attached the scrrenshots of results. 
http://genetics.bwh.harvard.edu/pph2/
PolyPhen-2 (Polymorphism Phenotyping v2) is a tool which predicts possible impact of an amino acid substitution.

Polyphan 2 is a good tool for predicting one amino acid mutation for organisms,But for humans it can predict for multiple changes in nucleotide seqeunces.As we are using S.Cerevisae so,I think SIFT would be better for that.


Some of my results from POLYPHAN 2



PDC1

emb|CAI4572181.1| BGP_1a_G0035200.mRNA.1.CDS.1 [Saccharomyces cerevisiae]
Position 201: Mutation: I->V
Link- http://genetics.bwh.harvard.edu/ggi/pph2/174f689a63a8354196123a39d2b6eea2081619bb/9646198.html

emb|CAI4594045.1| BDN_1c_G0035110.mRNA.1.CDS.1 [Saccharomyces cerevisiae] >emb|CAI7203244.1| BDN_1c_G0035110.mRNA.1.CDS.1 [Saccharomyces cerevisiae]:
Position 269: Mutation: K->R
Link-http://genetics.bwh.harvard.edu/ggi/pph2/174f689a63a8354196123a39d2b6eea2081619bb/9646202.html



PDC5

gb|EDV09430.1| pyruvate decarboxylase [Saccharomyces cerevisiae RM11-1a] >emb|CAI4615033.1| CFS_G0036420.mRNA.1.CDS.1 [Saccharomyces cerevisiae] >emb|CAI7406879.1| CFS_G0036420.mRNA.1.CDS.1 [Saccharomyces cerevisiae]:
Position 147: Mutation: A->T
Link - http://genetics.bwh.harvard.edu/ggi/pph2/174f689a63a8354196123a39d2b6eea2081619bb/9646219.html

emb|CAI6583647.1| CBM_HP1_G0031240.mRNA.1.CDS.1 [Saccharomyces cerevisiae]:
Position 484: Mutation: H->Y
Link - http://genetics.bwh.harvard.edu/ggi/pph2/174f689a63a8354196123a39d2b6eea2081619bb/9646236.html


PDC6

gb|EWG95875.1| Pdc6p [Saccharomyces cerevisiae R103]:
Position 296: Mutation: S->L
Link-http://genetics.bwh.harvard.edu/ggi/pph2/174f689a63a8354196123a39d2b6eea2081619bb/9646237.html


gb|EGA82850.1| Pdc6p [Saccharomyces cerevisiae Lalvin QA23]:
Position 322: Mutation: L->P
Link- http://genetics.bwh.harvard.edu/ggi/pph2/174f689a63a8354196123a39d2b6eea2081619bb/9646559.html


PDC2
dbj|GMC44067.1| unnamed protein product [Saccharomyces cerevisiae]:
Position 589: Mutation: M->T
Link - http://genetics.bwh.harvard.edu/ggi/pph2/174f689a63a8354196123a39d2b6eea2081619bb/9646564.html

dbj|GMC28090.1| unnamed protein product [Saccharomyces cerevisiae]:
Position 310: Mutation: K->N
Link -http://genetics.bwh.harvard.edu/ggi/pph2/174f689a63a8354196123a39d2b6eea2081619bb/9646580.html

