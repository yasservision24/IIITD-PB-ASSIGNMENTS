from Bio import SeqIO
import os
from Bio.Blast import NCBIWWW

def blastp_search(sequence, output_filename):
    organism = "Saccharomyces cerevisiae"
    e_value = 0.1
    max_target_seqs = 100

    # Perform BLASTP search
    handle = NCBIWWW.qblast(
        "blastp",
        "nr",  # Use "pdc" database for protein sequences
        sequence,
        entrez_query=f'{organism}[Organism]',
        expect=e_value,
        hitlist_size=max_target_seqs
    )

    # Write BLAST results to a file
    with open(output_filename, "w") as out_file:
        out_file.write(handle.read())

# List of sequences to search
sequences_to_search = [
   {"filename": "translated_PDC1_sequence.fasta", "output_filename": "amino_PDC1.xml"},
    {"filename": "translated_PDC5_sequence.fasta", "output_filename": "amino_PDC5.xml"},
   {"filename": "translated_PDC6_sequence.fasta", "output_filename": "amino_PDC6.xml"},
    {"filename": "translated_x_PDC2(expression_gene).fasta", "output_filename": "amino_PDC2.xml"},
]

# Perform BLASTP search for each sequence
print("BLASTPp search is in progress...")
for seq_info in sequences_to_search:
    current_directory = os.getcwd()
    

    # Define the path to the folder containing DNA sequence files
    folder_a_path1 = os.path.abspath(os.path.join(current_directory, '..', '..', r'ques3\BY_CODE\Normal_translated_sequences'))
   

    # Define the full path to the FASTA file
    fasta_file_path = os.path.join(folder_a_path1, seq_info["filename"])
  

    # Read sequences from the FASTA file
    records = SeqIO.parse(fasta_file_path, "fasta")
    
    # Perform BLASTP search for each sequence in the file
    for record in records:
        blastp_search(record.seq, seq_info["output_filename"])

print("BLASTP search completed.")


"""                                              OUTPUT OF THIS
This file would fetch all the result from NCBI by using BLASTp with respect to the query we translated in ques3
And save the reuslt in amino_PDC.xml files."""