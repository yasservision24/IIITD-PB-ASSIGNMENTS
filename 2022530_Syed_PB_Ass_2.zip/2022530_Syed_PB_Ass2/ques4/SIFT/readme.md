Ques4 - Select a SNP within the PDC gene. Utilize tools like SIFT (Sorting Intolerant From Tolerant) or PolyPhen (Polymorphism Phenotyping) to predict the impact of the SNP on the PDC protein function. (5 marks)

    ABSTRACT
    Single nucleotide polymorphism (SNP) studies and random mutagenesis projects identify amino acid substitutions in protein-coding regions. Each substitution has the potential to affect protein function. SIFT (Sorting Intolerant From Tolerant) is a program that predicts whether an amino acid substitution affects protein function so that users can prioritize substitutions for further study. We have shown that SIFT can distinguish between functionally neutral and deleterious amino acid changes in mutagenesis studies and on human polymorphisms. SIFT is available at https://sift.bii.a-star.edu.sg/.

    Single nucleotide polymorphisms (SNPs) are used as markers in linkage and association studies to detect which regions in the human genome may be involved in disease. SNPs in coding and regulatory regions may be implicated in disease themselves. Non-synonymous SNPs that lead to an amino acid change in the protein product are of major interest, because amino acid substitutions currently account for approximately half of the known gene lesions responsible for human inherited disease (1). SIFT (Sorting Intolerant From Tolerant) uses sequence homology to predict whether an amino acid substitution will affect protein function and hence, potentially alter phenotype

    To predict whether an amino acid substitution in a protein will affect protein function, SIFT considers the position at which the change occurred and the type of amino acid change. Given a protein sequence, SIFT chooses related proteins and obtains an alignment of these proteins with the query. Based on the amino acids appearing at each position in the alignment, SIFT calculates the probability that an amino acid at a position is tolerated conditional on the most frequent amino acid being tolerated. If this normalized value is less than a cutoff, the substitution is predicted to be deleterious (2). The SIFT algorithm and software have been described previously

# Source - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC168916/

Using SIFT,there are two methods for prediction,
    Genomic Tool AND Single Amino Tool

Genomic Tool

        We can make prediction by using nucleotide sequences for prediction,by giving file in VCF format,I was not able to predict based on genomic tool as I could not find much resource for VCF file format.

Single Amino Acid tool

        The SNP's present in genes finally alter the Amino Acid squence,So I used this tool for making predictions.

        Input format
            Query Amino Acid seq in FASTA format
            Substitution of interest in this format
                The format for a substitution is to have X#Y where X is the original amino acid, # is the position of the substitution and Y is the new amino acid. One substitution per line is allowed.

                Example:
                M1Y
                K3S
                T4P

            SIFT will return predictions on whether your substitutions are tolerant or intolerant based on the scores.

        Output format
            Predictions with scores and much more details

# Source - https://sift.bii.a-star.edu.sg/www/SIFT_help.html#substitution


Basic flow

    I first  found the protein seq of our refrence PDC1 gene of Saccharomyces cerevisiae S288C. https://www.ncbi.nlm.nih.gov/nuccore/BK006945.2/  
    After that I used the translated seq of SNP contaning PDC1 gene(used frame one 5'-3'),tool used -https://web.expasy.org/translate/
    After that using the code , I compared the  reference gene amino acid seq  with SNP containg PDC gene amino acid seq and found the locations of Single Amino Acid change. Named the file as protein alignment
    Now used the SIFT tool for prediction.


Some of the Single  Amino acid  subsititution

    #PDC5 strain JXXY16.1 
        #A137S
        #M235I
        #D236E
        #T356N
        #H373Q
        #E486Q






    #PDC5 cerevisiae strain XXYS1.4
        #A137S
        #M235I
        #D236E
        #T356N
        #H373Q
        #E486Q




    # PDC1 gene, mutant pdc1-14
        #A55R
        #A106S
        #A143C
        #A206V
        #V208A
        #D253S
        #T336N
        #S455F
        #I538V


    # PDC1 gene, mutant pdc1-8
        #A55R
        #A106S
        #A143S
        #A206V
        #V208A
        #D253S
        #D291N
        #T336N
        #I538V



Predictions 

    PDC1 gene, mutant pdc1-8       #  https://sift.bii.a-star.edu.sg//sift-bin/format.pl?ae3d473f90_sequences    

        Substitution at pos 55 from A to R is predicted to AFFECT PROTEIN FUNCTION with a score of 0.00.
            Median sequence conservation: 3.02
            Sequences represented at this position:85

        Substitution at pos 106 from A to S is predicted to be TOLERATED with a score of 1.00.
            Median sequence conservation: 3.02
            Sequences represented at this position:87

        Substitution at pos 143 from A to S is predicted to be TOLERATED with a score of 0.73.
            Median sequence conservation: 3.01
            Sequences represented at this position:89

        Substitution at pos 206 from A to V is predicted to be TOLERATED with a score of 0.06.
            Median sequence conservation: 3.01
            Sequences represented at this position:89

        Substitution at pos 208 from V to A is predicted to AFFECT PROTEIN FUNCTION with a score of 0.00.
            Median sequence conservation: 3.01
            Sequences represented at this position:89

        Substitution at pos 253 from D to S is predicted to AFFECT PROTEIN FUNCTION with a score of 0.04.
            Median sequence conservation: 3.01
            Sequences represented at this position:89

        Substitution at pos 291 from D to N is predicted to AFFECT PROTEIN FUNCTION with a score of 0.00.
            Median sequence conservation: 3.01
            Sequences represented at this position:89

        Substitution at pos 336 from T to N is predicted to be TOLERATED with a score of 0.41.
            Median sequence conservation: 3.01
            Sequences represented at this position:89

        Substitution at pos 538 from I to V is predicted to be TOLERATED with a score of 1.00.
            Median sequence conservation: 3.02
            Sequences represented at this position:86
            

        Substitution at pos 55 from A to R is predicted to AFFECT PROTEIN FUNCTION with a score of 0.01.
        Median sequence conservation: 3.06
        Sequences represented at this position:15







    PDC1 gene, mutant pdc1-14         # https://sift.bii.a-star.edu.sg//sift-bin/format.pl?36af3a9f1f_sequences

        Substitution at pos 106 from A to S is predicted to be TOLERATED with a score of 1.00.
            Median sequence conservation: 3.06
            Sequences represented at this position:15

        Substitution at pos 143 from A to C is predicted to be TOLERATED with a score of 0.14.
            Median sequence conservation: 3.06
            Sequences represented at this position:15

        Substitution at pos 206 from A to V is predicted to be TOLERATED with a score of 0.12.
            Median sequence conservation: 3.06
            Sequences represented at this position:15

        Substitution at pos 208 from V to A is predicted to AFFECT PROTEIN FUNCTION with a score of 0.01.
            Median sequence conservation: 3.06
            Sequences represented at this position:15

        Substitution at pos 253 from D to S is predicted to AFFECT PROTEIN FUNCTION with a score of 0.04.
            Median sequence conservation: 3.06
            Sequences represented at this position:15

        Substitution at pos 336 from T to N is predicted to be TOLERATED with a score of 0.51.
            Median sequence conservation: 3.06
            Sequences represented at this position:15

        Substitution at pos 455 from S to F is predicted to AFFECT PROTEIN FUNCTION with a score of 0.00.
            Median sequence conservation: 3.06
            Sequences represented at this position:15

        Substitution at pos 538 from I to V is predicted to be TOLERATED with a score of 1.00.
            Median sequence conservation: 3.06
            Sequences represented at this position:15





    PDC5 Saccharomyces cerevisiae strain JXXY16.1      #   https://sift.bii.a-star.edu.sg//sift-bin/format.pl?5fefdaa530_sequences

        Substitution at pos 137 from A to S is predicted to be TOLERATED with a score of 0.35.
            Median sequence conservation: 3.06
            Sequences represented at this position:15

        Substitution at pos 235 from M to I is predicted to be TOLERATED with a score of 1.00.
            Median sequence conservation: 3.06
            Sequences represented at this position:15

        Substitution at pos 236 from D to E is predicted to be TOLERATED with a score of 0.75.
            Median sequence conservation: 3.06
            Sequences represented at this position:15

        Substitution at pos 356 from T to N is predicted to be TOLERATED with a score of 1.00.
            Median sequence conservation: 3.06
            Sequences represented at this position:15

        Substitution at pos 373 from H to Q is predicted to be TOLERATED with a score of 0.63.
            Median sequence conservation: 3.06
            Sequences represented at this position:15

        Substitution at pos 486 from E to Q is predicted to be TOLERATED with a score of 0.67.
            Median sequence conservation: 3.06
            Sequences represented at this position:15




    PDC5 Saccharomyces cerevisiae strain XXYS1.4    #https://sift.bii.a-star.edu.sg//sift-bin/format.pl?4497b95d54_sequences

        Substitution at pos 137 from A to S is predicted to be TOLERATED with a score of 0.35.
        Median sequence conservation: 3.06
        Sequences represented at this position:15

        Substitution at pos 235 from M to I is predicted to be TOLERATED with a score of 1.00.
            Median sequence conservation: 3.06
            Sequences represented at this position:15

        Substitution at pos 236 from D to E is predicted to be TOLERATED with a score of 0.75.
            Median sequence conservation: 3.06
            Sequences represented at this position:15

        Substitution at pos 356 from T to N is predicted to be TOLERATED with a score of 1.00.
            Median sequence conservation: 3.06
            Sequences represented at this position:15

        Substitution at pos 373 from H to Q is predicted to be TOLERATED with a score of 0.63.
            Median sequence conservation: 3.06
            Sequences represented at this position:15

        Substitution at pos 486 from E to Q is predicted to be TOLERATED with a score of 0.67.
            Median sequence conservation: 3.06
            Sequences represented at this position:15


PDC6

    emb|CAI4928256.1| CGH_1_HP_G0021960.mRNA.1.CDS.1 [Saccharomyces cerevisiae]  https://sift.bii.a-star.edu.sg//sift-bin/format.pl?8a3fe2d1de_sequences


    Substitution at pos 151 from R to S is predicted to be TOLERATED with a score of 0.08.
    Median sequence conservation: 3.07
    Sequences represented at this position:15



PDC2

    gb|AJU61381.1| Pdc2p [Saccharomyces cerevisiae YJM270]    https://sift.bii.a-star.edu.sg//sift-bin/format.pl?c685884504_sequences


    Substitution at pos 310 from K to N is predicted to be TOLERATED with a score of 0.13.
    Median sequence conservation: 4.32
    Sequences represented at this position:11



I have attached the images of search pages also in the folder PDC1 AND PDC5