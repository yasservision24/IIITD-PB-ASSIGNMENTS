"""# Saccharomyces cerevisiae, also known as brewer's or baker's yeast,it is an Eukaryote.
# We can download its genome sequence from NCBI using the following code and store it in the local machine.
# Here I am using the Biopython Libraray and its Module Entrez and SeqIO for this task'
# I downloades the genome seqeunce of  genome R64 Saccharomyces Genome Database (2014). Strain: S288C.
# https://www.ncbi.nlm.nih.gov/datasets/genome/GCF_000146045.2/"""

from Bio import Entrez # The Entrez module in Biopython Library provides functions for accessing NCBI's Entrez databases.
from Bio import SeqIO # The SeqIO module in Biopython provides functions for reading and writing sequence data in various formats.

def download_sequences(accession_list): # Function to download the dataset using the accesion number.
    
    # Enter email for NCBI compliance
    Entrez.email = "syed22530@iiitd.ac.in"

    fetched_sequences = [] # A list to add the accession number and dna_sequence

    # Fetching  sequences using accession numbers
    for accession in accession_list:
        try: # Using try catch Exception to avoid any error if the fetching of data fails
            handle = Entrez.efetch(db="nucleotide", id=accession, rettype="gb", retmode="text")
            record = SeqIO.read(handle, "genbank") # Using the genbank dataset and its accesion no
            handle.close()
            # Extracting  the DNA sequence from the record
            dna_sequence = str(record.seq)
            fetched_sequences.append((accession, dna_sequence))
        except Exception as e:
            print(f"Error fetching sequence for accession {accession}: {str(e)}")

    return fetched_sequences
# These are the Accesion Number for all the 16 Chromosomes and the 17th mitochondrial chromosome
# The accesion numbers in the list accessio_list are in the order of chromosome,i.e. first element is chromosome 1  and so on.
"""I am using the List to store all the accession no. of all chromosomes and then using the loop, I am calling
the function download_sequences to download all the genome database"""

accession_list = ['BK006935.2','BK006936.2', 'BK006937.2', 'BK006938.2', 'BK006939.2', 'BK006940.2',
                  'BK006941.2', 'BK006934.2', 'BK006942.2', 'BK006943.2', 'BK006944.2', 'BK006945.2',
                  'BK006946.2', 'BK006947.3', 'BK006948.2', 'BK006949.2','KP263414.1']


# Fetch DNA sequences for all accession numbers by calling the function download_Sequences
print("Wait sequence is uploading to your local machine based on your Internet speed....")
sequences_data = download_sequences(accession_list)

# Write sequences to the FASTA file
""" FASTA is a commonly used file format for representing biological sequences, 
such as nucleotide sequences (DNA or RNA) or protein sequences.
It's a simple and widely recognized format that consists of a header line followed by the sequence data."""

with open("sequences.fasta", "w") as fasta_file: # Open the file seqeunces.fasta in the 'w' means write mode 
    for acc, seq in sequences_data:
        fasta_file.write(f">{acc}\n{seq}\n")  # this line prints the accession no of each chromosome seqeunce,Thus representing seqeunce of each chromosome
        #fasta_file.write(f"{seq}\n")         # this line just prints out the seqeunce without printing accesion no. of each chromosome.
        

        
print("Sequences downloaded and saved as 'sequences.fasta'")
