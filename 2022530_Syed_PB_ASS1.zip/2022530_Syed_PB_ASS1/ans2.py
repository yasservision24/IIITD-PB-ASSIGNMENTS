"""In Python, re is a module that provides support for regular expressions (regex).
Regular expressions are patterns used to match character combinations in strings. """

import re # Importing regular expression
from Bio import Entrez
from Bio import SeqIO 
ori = []  # Initialize list to store ORI index

def calculate_at_content(region): # here I am defining the function which finds the AT content in the given region 
    count_AT = region.count('A') + region.count('T')
    return (count_AT / len(region)) * 100 #Her returns the percentage of AT content

# Using the regular expression match the string with upto 1 mismatch allowed with the ACS motif
# ACS(ARS consensus sequences) motif of 11 base pair  (T/A) TTTAT (A/G) TTT (T/A)           

    
    """ I first identified the potential essential 11-bp ACS(ARS consensus sequences) (T/A) TTTAT (A/G) TTT (T/A) 
           using the regular expression module with upto 1 mismatch, This gives me about ~12500 indices.
           As motif [WWWWTTTAYRTTTWGTT], where W = A or T, Y = C or T, and R = A or G, I will use the most important 11 bp
           motif using regex to get every possible match,with 1 mismatch allowed.
           Here,I got more than 12000 matches.there are >12,000 potential ACS matches in the genome but ~400 origins, 
                #source - https://genesdev.cshlp.org/content/20/14/1874.full   
                #Source - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6753640/#SM1   
           Here,I got ~12000 matches(Acs)"""
           
def find_matches(sequence):
       # In below line  regular expression is using a lookahead (?= ... )     
    pattern = r'(?=(?:T{1}T{1}ATGTTT|A{1}T{1}ATGTTT|T{1}T{1}AGGTTT|A{1}T{1}AGGTTT|T{1}T{1}ATTTTA|A{1}T{1}ATTTTA|T{1}T{1}AGTTTA|A{1}T{1,2}AGTTTA|T{1}T{1}ATGTTA|A{1}T{1}ATGTTA|T{1}T{1}AGGTTA|A{1}T{1}AGGTTA|T{1}T{1,2}ATTTTT|A{1}T{1}ATTTTT|T{1,2}T{1,2}AGTTTT|A{1,2}T{1,2}AGTTTT))'
    
    matches = re.finditer(pattern, sequence) # find all occurrences of the pattern in the given sequence.
    indices = [match.start() for match in matches] #  extracts the starting index of each match 
    return indices #  returns the list of indices where the specified motifs were found in the DNA sequence.

# Here I will use the dataset downloaded in question1
# function reads a FASTA file of sequences and returns a single string of all the sequences
def read_fasta_file(file_path):
    sequences = ""
    with open(file_path, 'r') as file: # opening the file in the read 'r' mode
        for line in file:
            line = line.strip()
            if not line.startswith('>'): # to remove the header i.e. accesion no in fasta file
                sequences += line
    print("")
    print("Lenth of all genome seqeunce:- ",len(sequences))
    print("")
    return sequences

#  remove overlapping indices from the ori_list
def remove_overlapping_indices(ori_list):
    i = 0
    while i < len(ori_list) - 1:
        if ori_list[i + 1] - ori_list[i] < 6000:
            # Remove the next index if the difference is less than 6000
            ori_list.pop(i + 1)
        else:
            # Move to the next index
            i += 1
         
# Main function from where all the functions will be called
def main():
    file_path = 'sequences.fasta'
    sequence = read_fasta_file(file_path)
    matches = find_matches(sequence) # there are >12,000 potential ACS(ARS consensus sequence)
    #A match to the ACS is essential but not sufficient
    print("No of all potential matches based on ACS motif match:- ",len(matches))
    print("")
    #print(matches) # You can print matches also
    for index in matches:
        try: #Using try catch to avoid any potential exception
            origin = sequence[index]  # Consider the index as origin
            # Extract regions, catching any potential IndexError exceptions
            
            region1 = sequence[index - 9: index - 108: -1] # selectiong the region1 prior to 5'end
            region2 = sequence[index + 107: index + 154]   # selcting the region2 prior to 3' end
            region3 = sequence[index + 11: index +108 ]    # selcting the region3 prior to 3' end

            # Calculate AT content for regions and A content
            region1_at_content = calculate_at_content(region1) # Calculate AT content for region1
            region2_at_content = calculate_at_content(region2) #  Calculate AT content for region2
            region3_A_content = (region3.count('A') / len(region3)) * 100 # Calculate A content for region3

            # Check conditions as stated above in the comment
            if region1_at_content > 70.35 and region2_at_content > 68 : 
                """genome of S. Cerevisiae has an average GC content of 38.38%, while that of ORI sequences is only 29.65%
                    100-29.65=70.35 
                        #source - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6753640/#SM1"""
                ori.append(index)  # Append index to ori list

        except IndexError:
            # Skip this index if it causes an IndexError due to going out of bounds
            pass
    print("No of potential ARS:- ",len(ori))
    print("Since there are >12,000 potential ACS matches in the genome but ~400 origins\n  #source - https://genesdev.cshlp.org/content/20/14/1874.full\n  #Source - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6753640/#SM1       ")
    
    
            
            
            
    remove_overlapping_indices(ori) # Here I am removing the overlapping indices as there 
    print("")
    print("No of ORI:- ",len(ori)) 
    print("S. cerevisiae genome comprises more than 12,000 potential ACS sites and approximately 400 origins")
    print("#source- https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4971157/")

    print("")
    if ori:
        print(f"ORI may be present at these locations : {ori}")
       
    else:
        print("No matches found.")

if __name__ == "__main__":
    main() # Calling the main function using the __name__
    
    
"""_________________________________________LOGIC & EXPLANATION ______________________________________""" 
    
""" 
    * As we know Saccharomyces cerevisiae, also known as brewer's or baker's yeast, is an Eukaryote.So here DNA would be linear and would have multiple discrete
      replication origin,each of which initiates two diverging replication forks. 
      Eukaryotic chromosomes are replicated from multiple discrete sites.
      Eukaryotic chromosomes are linear and have multiple ORIs.    
                # source -  https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4971157/
    
    * In a typical DNA replication process, each parent DNA is duplicated precisely and entirely before cell division takes place. 
        DNA unwinding and loading of replication machinery happens at specific sites called origin of replication (ORI) or replication sites.
    
    * There are certain characteristics of ORI and I would identify those characterisitics to identify the ORI.
    
    * Some important characters for ORI are:
    
    1.    There is a special seqeunce known as ARS(Autonomous Replicating Sequence). 
            An autonomously replicating sequence (ARS) contains the origin of replication in the yeast genome. 
            It contains four regions (A, B1, B2, and B3), named in order of their effect on plasmid stability.
            
    2.    ARS contains an essential 11-bp ACS(ARS consensus sequences) motif  [5'--3'] (T/A) TTTAT (A/G) TTT (T/A)
            sometimes represented as an extended 17-bp motif [WWWWTTTAYRTTTWGTT], where W = A or T, Y = C or T, and R = A or G based on a larger number of origins
            and three non-essential elements i.e. B1, B2, and B3. 
                #    Source -  https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4971157/
                #    source -  https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4971157/
                #    sourse -  https://genesdev.cshlp.org/content/20/14/1874.full 
                #    source -  (Theis and Newlon 1997)
                #    source -  https://onlinelibrary.wiley.com/doi/full/10.1002/elsc.202000085
        
    3.    The minimum size of ARS function in Saccharomyces cerevisiae is within 100-250 bps, and can upto 1500 bp
            Genome-wide experimental studies in Saccharomyces cerevisiae reveal that autonomous replicating sequence (ARS)
            requires an essential  ARS consensus sequence (ACS) for replication activity. 
                #source -  https://onlinelibrary.wiley.com/doi/full/10.1002/elsc.202000085   
                
    4.    Since there are >12,000 potential ACS matches in the genome but ~400 origins, 
            thus, this motif is not sufficient to predict origin location. 
            So,A match to the ACS is essential but not sufficient for origin of replication.
               #source - https://genesdev.cshlp.org/content/20/14/1874.full          
               
    5.    Thus,We will use one of the other property to refine the search for the ORI of The S. cerevisiae S288C genome sequence,
            that is,genome of S. Cerevisiae has an average GC content of 38.38%, while that of ORI sequences is only 29.65%
                #source - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6753640/#SM1  
                
    6.    Another property is,The region 3' to the ACS contains a high proportion of A residues (approximately 44%; Figure 1a).
            In the ACS, there are 3.0 Ts for every A, and this ratio changes to 0.6 in this A-rich area.
                #source - https://genomebiology.biomedcentral.com/articles/10.1186/gb-2004-5-4-r22  
                
    7.    The 100 nucleotides immediately 5' to the ACS (-108 to -9 bp relative to the ACS) had a significantly higher A+T content (70.35) and the 53 nucleotides
            3' to the A-rich region (+107 to +159 bp) had a significantly higher A+T content (68%) than 
            bulk sequence (62%; p < 0.001).    
            Inclusion of these sequences improved the performance of Oriscan, 
            but use of sequences further from the ACS degraded performance. 
            In search for replication origins, therefore, we chose to use sequences from -108 to +159 bp,
            including both the A-rich region and both areas of increased AT content.And consider the ACS at origin.
                #source - https://genomebiology.biomedcentral.com/articles/10.1186/gb-2004-5-4-r22
                #source - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6753640/#SM1   
            
    8.     Property 5,6,7  together forms a ARS,
            Thus after this I got around 1400 indices,Or we can say we got around 1400 ARS.
                #Source - https://genomebiology.biomedcentral.com/articles/10.1186/gb-2004-5-4-r22
                #Source - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6753640/#SM1  
                   
    * To identitify the ORI I did the following steps:
    
    1.    I first identified the potential essential 11-bp ACS(ARS consensus sequences) (T/A) TTTAT (A/G) TTT (T/A) 
           using the regular expression module with upto 1 mismatch, This gives me about ~12500 indices.
           As motif [WWWWTTTAYRTTTWGTT], where W = A or T, Y = C or T, and R = A or G,I will use the most important 11 bp
           motif using regex to get every possible match,with 1 mismatch allowed.
           Here,I got more than 12000 matches.there are >12,000 potential ACS matches in the genome but ~400 origins, 
                #source - https://genesdev.cshlp.org/content/20/14/1874.full   
                #Source - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6753640/#SM1   
           Here,I got ~12000 matches(Acs)
            
    2.     Then I selects only those which have higher AT content in neighborhood ,
            i.e. more than 68% along with region of higher A content,i.e. more than 44%.Thymine
            Here,I got ~1400 matches(ARS)
                #Source - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6753640/#SM1   
            
    3.     To narrow down the search, I select only those indices which are about 6000 bp apart,
            As there is less possbility of them being together.
            ARSs can interact with each other and two ARSs with a distance of 6.5 kbp can cause the mutual interference.
            Replication is generally initiated by one ARS, and the probability of two ARS initiating replication on the same DNA molecule is <5% 
            Thus I am removing consecutive indices where difference is less than 5000
                #Source - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6753640/#SM1
                #source -https://onlinelibrary.wiley.com/doi/full/10.1002/elsc.202000085
    
            Here,I got ~400 ORI.
            (S. cerevisiae genome comprises more than 12,000 potential ACS sites and approximately 400 origins
                #source- https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4971157/)   
"""