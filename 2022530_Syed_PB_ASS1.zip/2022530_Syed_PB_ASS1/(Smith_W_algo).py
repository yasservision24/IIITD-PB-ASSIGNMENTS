import numpy as np

# Smith-Waterman algorithm for local sequence alignment
def smith_waterman(seq1, seq2, match_score=2, mismatch_score=-1, gap_penalty=-1):
    n = len(seq1)
    m = len(seq2)
    
    # Initialize score matrix
    score = np.zeros((n+1, m+1))
    
    # Initialize traceback matrix
    traceback = np.zeros((n+1, m+1))
    
    # Initialize variables to keep track of the maximum score and its position
    max_score = 0
    max_i, max_j = 0, 0
    
    # Fill in the score and traceback matrices
    for i in range(1, n+1):
        for j in range(1, m+1):
            match = score[i-1][j-1] + (match_score if seq1[i-1] == seq2[j-1] else mismatch_score)
            delete = score[i-1][j] + gap_penalty
            insert = score[i][j-1] + gap_penalty
            score[i][j] = max(0, match, delete, insert)  # local alignment, so negative scores are set to 0
            
            # Update traceback matrix
            if score[i][j] == 0:
                traceback[i][j] = 0  # end of alignment
            elif score[i][j] == match:
                traceback[i][j] = 1  # diagonal
            elif score[i][j] == delete:
                traceback[i][j] = 2  # up
            else:
                traceback[i][j] = 3  # left
            
            # Update maximum score and its position
            if score[i][j] > max_score:
                max_score = score[i][j]
                max_i, max_j = i, j
    
    # Traceback to find the aligned sequences
    aligned_seq1 = ""
    aligned_seq2 = ""
    i, j = max_i, max_j
    while i > 0 and j > 0 and score[i][j] > 0:
        if traceback[i][j] == 1:  # diagonal
            aligned_seq1 = seq1[i-1] + aligned_seq1
            aligned_seq2 = seq2[j-1] + aligned_seq2
            i -= 1
            j -= 1
        elif traceback[i][j] == 2:  # up
            aligned_seq1 = seq1[i-1] + aligned_seq1
            aligned_seq2 = "-" + aligned_seq2
            i -= 1
        else:  # left
            aligned_seq1 = "-" + aligned_seq1
            aligned_seq2 = seq2[j-1] + aligned_seq2
            j -= 1
    
    return aligned_seq1, aligned_seq2, max_score

# Read the sequence from a FASTA file
def read_fasta(filename):
    with open(filename, 'r') as file:
        sequence = file.read().replace('\n', '')
    return sequence

# Main function
def main():
    # Read the sequence from the FASTA file
    sequence = read_fasta("sequences.fasta")
    print("")
    print("Please wait  output is being generated based on you machine processor performance....")
    
    # Define the motifs to search for
    motifs = ["AAAAATTTACATTT", "AAAAATTTATGTTT", "TTTTTTTTACATTT", "TTTTTTTTATGTTT", "AAAAATTTACATTT", "AAAAATTTATGTTT", "TTTTTTTTACATTT", "TTTTTTTTATGTTT"]
    # Perform Smith-Waterman alignment for each index of the sequence
    matches = []
    for i in range(len(sequence)):
        motif_found = False
        for motif in motifs:
            if motif_found:
                break
            aligned_seq1, aligned_seq2, score = smith_waterman(sequence[i:i+len(motif)], motif)
            if score > 22:  # Accept alignments with score 22 
                #matches.append((i, motif, score, aligned_seq1, aligned_seq2))
                matches.append((i, score))
                motif_found = True
    
    # Print the matches
    for result in matches:
        print(f"Motif {result[1]} aligned with the sequence starting at index {result[0]} with score {result[1]}.")
        # print("Aligned Sequence 1:", result[3])
        # print("Aligned Sequence 2:", result[4])
        print()
    print(len(result))

if __name__ == "__main__":
    main()
    